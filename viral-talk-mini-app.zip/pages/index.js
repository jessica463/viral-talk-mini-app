export default function Home() {
  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "2rem" }}>
      <h1>🚀 ViralTalk Mini App</h1>
      <p>
        Welcome to <strong>ViralTalk</strong> – where project owners promote their projects 
        and participants win rewards for creating quality content.
      </p>

      <h2>How It Works</h2>
      <ol>
        <li>Project Owners deposit money (minimum $10).</li>
        <li>Participants join free and submit one post.</li>
        <li>Top 5 posts win and share the prize pool.</li>
        <li>Payouts go directly to verified crypto wallets.</li>
      </ol>

      <p style={{ marginTop: "2rem" }}>
        ✅ Transparent • 🎨 Fair • 🔗 Blockchain-powered
      </p>
    </div>
  );
}
